
import java.util.Arrays;

public class Machamp extends PokemonInfo{
	
	public Machamp () {
		super("Machamp", "Fighting", 384, Arrays.asList(new Attack("Karate Chop", "Fighting", 50), new Attack("Low Sweep", "Fighting", 60), new Attack("Wake-Up Slap", "Fighting", 60), new Attack("Cross Chop", "Fighting", 80)));
		  
	}

}
