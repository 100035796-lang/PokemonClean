public class PokemonTester {
    public static void main(String[] args) {
        Blastoise b = new Blastoise();
        b.printInfo();
    }
}
