
import java.util.Arrays;

public class Blastoise extends PokemonInfo{
	
	public Blastoise() {
		super("Blastoise", "Water", 362, Arrays.asList(new Attack("Hydro Pump", "Water", 120), new Attack("Bite", "Dark", 60), new Attack("Tackle", "Normal", 50), new Attack("Flash Cannon", "Steel", 80)));
		  
	}
//	Attack hydropump = new Attack("Hydro Pump", "Water", 120);
//	Attack bite = new Attack("Bite", "Dark", 60);
//	Attack tackle = new Attack("Tackle", "Normal", 50);
//	Attack flashcannon = new Attack("Flash Cannon", "Steel", 80);
//	
//	PokemonInfo Blastoise = new PokemonStats("Blastoise", "Water", 362, Arrays.asList(hydropump, bite, tackle, flashcannon));
//    
    
}
