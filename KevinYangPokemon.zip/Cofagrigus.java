
import java.util.Arrays;

public class Cofagrigus extends PokemonInfo{
	
	public Cofagrigus () {
		super("Cofagrigus", "Ghost", 320, Arrays.asList(new Attack("Astonish", "Ghost", 40), new Attack("Disable", "Normal", 20), new Attack("Shadow Ball", "Ghost", 80), new Attack("Ominous Wind", "Ghost", 100)));
		  
	}

}
