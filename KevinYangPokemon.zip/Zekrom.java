
import java.util.Arrays;

public class Zekrom extends PokemonInfo{
	
	public Zekrom() {
		super("Zekrom", "Dark, Electric", 404, Arrays.asList(new Attack("Bolt Strike", "Electric", 110), new Attack("Slash", "Normal", 70), new Attack("Zen Headbutt", "Psychic", 80), new Attack("Ancient Power", "Rock", 60)));
		  
	}

}
