
import java.util.Arrays;

public class Venusaur extends PokemonInfo{
	
	public Venusaur () {
		super("Venusaur", "Grass, Poison", 364, Arrays.asList(new Attack("Poison Powder", "Poison", 60), new Attack("Take Down", "Normal", 90), new Attack("Petal Dance", "Gras", 120), new Attack("Razor Leaf", "Grass", 55)));
		  
	}

}
