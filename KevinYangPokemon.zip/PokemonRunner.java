
public class PokemonRunner {
	public static void main(String[] args) {
		PokemonGameWithPictures.startGame();
	}
}
